<!DOCTYPE html>
<html>

    <head>
        <title>LAMP Stack on AWS Elastic Beanstalk</title>
        <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 0;
            margin: 0;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            max-width: 1000px;
            margin: 40px auto;
        }

        h1 {
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
            text-align: center;
        }

        .info {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 20px 0;
            border-left: 4px solid #667eea;
        }

        .success {
            color: #28a745;
            font-weight: bold;
        }

        .error {
            color: #dc3545;
            font-weight: bold;
        }

        .warning {
            color: #ffc107;
            font-weight: bold;
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            background-color: #667eea;
            color: white;
            border-radius: 4px;
            font-size: 12px;
            margin-left: 10px;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .feature-box {
            background: linear-gradient(45deg, #f1f3f4, #e8eaf6);
            padding: 20px;
            border-radius: 10px;
            border: 1px solid #e0e0e0;
        }

        .architecture-info {
            background: linear-gradient(45deg, #e8f5e8, #f0f8ff);
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
        }
        </style>
    </head>

    <body>
        <div class="container">
            <h1>🚀 LAMP Stack Application on AWS Elastic Beanstalk</h1>

            <div class="architecture-info">
                <h2>🏗️ AWS Architecture Information</h2>
                <p><strong>Deployment:</strong> AWS Elastic Beanstalk with Load Balancer</p>
                <p><strong>Auto Scaling:</strong> Min: 2 instances, Max: 8 instances</p>
                <p><strong>Scaling Triggers:</strong> Network Output (Upper: 60%, Lower: 30%)</p>
                <p><strong>High Availability:</strong> Multi-AZ RDS deployment</p>
                <p><strong>Security:</strong> Custom VPC with public subnets in multiple AZs</p>
            </div>

            <div class="info">
                <h2>📊 Server Information</h2>
                <p><strong>Server:</strong> <?php echo $_SERVER['SERVER_NAME']; ?> <span class="badge">Live</span></p>
                <p><strong>Server IP:</strong> <?php echo $_SERVER['SERVER_ADDR'] ?? 'N/A'; ?></p>
                <p><strong>Instance ID:</strong>
                    <?php 
                $instanceId = file_get_contents('http://169.254.169.254/latest/meta-data/instance-id');
                echo $instanceId ?: 'N/A'; 
                ?>
                </p>
                <p><strong>Availability Zone:</strong>
                    <?php 
                $az = file_get_contents('http://169.254.169.254/latest/meta-data/placement/availability-zone');
                echo $az ?: 'N/A'; 
                ?>
                </p>
                <p><strong>PHP Version:</strong> <?php echo phpversion(); ?> <span class="badge">Active</span></p>
                <p><strong>Current Time:</strong> <?php echo date('Y-m-d H:i:s T'); ?></p>
            </div>

            <div class="info">
                <h2>🗄️ Database Connection Test</h2>
                <?php
            // Use environment variables from Elastic Beanstalk
            $dbhost = getenv('RDS_HOSTNAME');
            $dbport = getenv('RDS_PORT');
            $dbname = getenv('RDS_DB_NAME');
            $username = getenv('RDS_USERNAME');
            $password = getenv('RDS_PASSWORD');

            if ($dbhost && $dbport && $dbname && $username && $password) {
                try {
                    $pdo = new PDO("mysql:host=$dbhost;port=$dbport;dbname=$dbname", $username, $password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                    echo '<p class="success">✅ Database connection successful!</p>';
                    echo '<p><strong>Database Host:</strong> ' . $dbhost . '</p>';
                    echo '<p><strong>Database Name:</strong> ' . $dbname . '</p>';
                    
                    // Test query to get MySQL version
                    $stmt = $pdo->query('SELECT VERSION() as version');
                    $version = $stmt->fetch();
                    echo '<p><strong>MySQL Version:</strong> ' . $version['version'] . '</p>';
                    
                    // Create a test table and insert sample data
                    $pdo->exec("CREATE TABLE IF NOT EXISTS app_status (
                        id INT AUTO_INCREMENT PRIMARY KEY,
                        status VARCHAR(50),
                        timestamp DATETIME,
                        instance_id VARCHAR(20)
                    )");
                    
                    $instanceId = file_get_contents('http://169.254.169.254/latest/meta-data/instance-id') ?: 'unknown';
                    $stmt = $pdo->prepare("INSERT INTO app_status (status, timestamp, instance_id) VALUES (?, NOW(), ?)");
                    $stmt->execute(['active', $instanceId]);
                    
                    // Get recent records
                    $stmt = $pdo->query("SELECT * FROM app_status ORDER BY timestamp DESC LIMIT 5");
                    $records = $stmt->fetchAll();
                    
                    echo '<h3>Recent Activity:</h3>';
                    echo '<table style="width:100%; border-collapse: collapse;">';
                    echo '<tr style="background-color: #f0f0f0;"><th style="border:1px solid #ddd; padding:8px;">Status</th><th style="border:1px solid #ddd; padding:8px;">Timestamp</th><th style="border:1px solid #ddd; padding:8px;">Instance ID</th></tr>';
                    foreach($records as $record) {
                        echo '<tr>';
                        echo '<td style="border:1px solid #ddd; padding:8px;">' . htmlspecialchars($record['status']) . '</td>';
                        echo '<td style="border:1px solid #ddd; padding:8px;">' . htmlspecialchars($record['timestamp']) . '</td>';
                        echo '<td style="border:1px solid #ddd; padding:8px;">' . htmlspecialchars($record['instance_id']) . '</td>';
                        echo '</tr>';
                    }
                    echo '</table>';
                    
                } catch(PDOException $e) {
                    echo '<p class="error">❌ Database connection failed: ' . $e->getMessage() . '</p>';
                }
            } else {
                echo '<p class="warning">⚠️ Database environment variables not configured</p>';
                echo '<p>Missing variables: ';
                $missing = [];
                if (!$dbhost) $missing[] = 'RDS_HOSTNAME';
                if (!$dbport) $missing[] = 'RDS_PORT'; 
                if (!$dbname) $missing[] = 'RDS_DB_NAME';
                if (!$username) $missing[] = 'RDS_USERNAME';
                if (!$password) $missing[] = 'RDS_PASSWORD';
                echo implode(', ', $missing) . '</p>';
            }
            ?>
            </div>

            <div class="grid">
                <div class="feature-box">
                    <h3>🔧 PHP Extensions</h3>
                    <p><?php 
                $extensions = get_loaded_extensions();
                sort($extensions);
                echo implode(', ', array_slice($extensions, 0, 15));
                if (count($extensions) > 15) echo '... and ' . (count($extensions) - 15) . ' more';
                ?></p>
                </div>

                <div class="feature-box">
                    <h3>🌐 Environment Info</h3>
                    <p><strong>RDS_HOSTNAME:</strong> <?php echo getenv('RDS_HOSTNAME') ?: 'Not set'; ?></p>
                    <p><strong>RDS_PORT:</strong> <?php echo getenv('RDS_PORT') ?: 'Not set'; ?></p>
                    <p><strong>RDS_DB_NAME:</strong> <?php echo getenv('RDS_DB_NAME') ?: 'Not set'; ?></p>
                    <p><strong>RDS_USERNAME:</strong> <?php echo getenv('RDS_USERNAME') ?: 'Not set'; ?></p>
                </div>
            </div>

            <div class="info">
                <h2>📈 Performance & Monitoring</h2>
                <p><strong>Memory Usage:</strong> <?php echo round(memory_get_usage(true) / 1024 / 1024, 2); ?> MB</p>
                <p><strong>Peak Memory:</strong> <?php echo round(memory_get_peak_usage(true) / 1024 / 1024, 2); ?> MB
                </p>
                <p><strong>Script Execution Time:</strong>
                    <?php echo round(microtime(true) - $_SERVER['REQUEST_TIME_FLOAT'], 4); ?> seconds</p>
            </div>

            <div class="architecture-info">
                <h2>✅ AWS Services Used</h2>
                <ul>
                    <li>AWS Elastic Beanstalk (Application Platform)</li>
                    <li>Amazon EC2 (Compute Instances)</li>
                    <li>Custom AMI (LAMP Stack Image)</li>
                    <li>Application Load Balancer (Traffic Distribution)</li>
                    <li>Auto Scaling Groups (Scalability)</li>
                    <li>Amazon RDS MySQL (Multi-AZ Database)</li>
                    <li>Amazon VPC (Custom Network)</li>
                    <li>Security Groups (Network Security)</li>
                    <li>Amazon SNS (Email Notifications)</li>
                </ul>
            </div>
        </div>
    </body>

</html>