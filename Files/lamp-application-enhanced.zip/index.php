<?php
// LAMP Stack Application - Complete Test
echo "<h1>🚀 LAMP Stack Application on AWS Elastic Beanstalk</h1>";

// Test 1: Basic PHP functionality
echo "<h2>✅ PHP Testing</h2>";
echo "<p><strong>PHP Version:</strong> " . PHP_VERSION . "</p>";
echo "<p><strong>Server:</strong> " . $_SERVER['SERVER_SOFTWARE'] . "</p>";
echo "<p><strong>Server Time:</strong> " . date('Y-m-d H:i:s T') . "</p>";

// Test 2: MySQL Extension Check
echo "<h2>✅ MySQL Extension Testing</h2>";
if (extension_loaded('mysqli')) {
    echo "<p><strong>MySQLi Extension:</strong> ✅ Loaded</p>";
} else {
    echo "<p><strong>MySQLi Extension:</strong> ❌ Not Loaded</p>";
}

if (extension_loaded('pdo_mysql')) {
    echo "<p><strong>PDO MySQL Extension:</strong> ✅ Loaded</p>";
} else {
    echo "<p><strong>PDO MySQL Extension:</strong> ❌ Not Loaded</p>";
}

// Test 3: Database Connectivity
echo "<h2>🗄️ Database Connectivity Testing</h2>";

// Database configuration
$db_host = 'lamp-app-db.cijnrr1efnu0.us-east-1.rds.amazonaws.com';
$db_name = 'lampapp';
$db_user = 'lampdbadmin';
$db_pass = 'MySecurePassword123!';

try {
    // Test MySQLi connection
    $mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
    if ($mysqli->connect_error) {
        echo "<p><strong>MySQLi Connection:</strong> ❌ Failed - " . $mysqli->connect_error . "</p>";
    } else {
        echo "<p><strong>MySQLi Connection:</strong> ✅ Success</p>";
        echo "<p><strong>Database Version:</strong> " . $mysqli->server_info . "</p>";
        
        // Test creating a table and inserting data
        $sql = "CREATE TABLE IF NOT EXISTS test_table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            message VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        if ($mysqli->query($sql)) {
            echo "<p><strong>Table Creation:</strong> ✅ Success</p>";
            
            // Insert test data
            $insert_sql = "INSERT INTO test_table (message) VALUES ('LAMP Stack Working!')";
            if ($mysqli->query($insert_sql)) {
                echo "<p><strong>Data Insert:</strong> ✅ Success</p>";
                
                // Retrieve data
                $result = $mysqli->query("SELECT * FROM test_table ORDER BY created_at DESC LIMIT 5");
                if ($result->num_rows > 0) {
                    echo "<p><strong>Data Retrieval:</strong> ✅ Success</p>";
                    echo "<h3>Recent Database Entries:</h3>";
                    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
                    echo "<tr><th>ID</th><th>Message</th><th>Created At</th></tr>";
                    
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["id"] . "</td>";
                        echo "<td>" . $row["message"] . "</td>";
                        echo "<td>" . $row["created_at"] . "</td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                }
            }
        }
        $mysqli->close();
    }
    
    // Test PDO connection
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p><strong>PDO Connection:</strong> ✅ Success</p>";
    
} catch (Exception $e) {
    echo "<p><strong>Database Connection:</strong> ❌ Failed - " . $e->getMessage() . "</p>";
}

// Test 4: Environment Information
echo "<h2>🌐 Environment Information</h2>";
echo "<p><strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<p><strong>Script Name:</strong> " . $_SERVER['SCRIPT_NAME'] . "</p>";
echo "<p><strong>Request Method:</strong> " . $_SERVER['REQUEST_METHOD'] . "</p>";
echo "<p><strong>User Agent:</strong> " . $_SERVER['HTTP_USER_AGENT'] . "</p>";

// Test 5: Instance Information
echo "<h2>☁️ AWS Instance Information</h2>";
$instance_id = @file_get_contents('http://169.254.169.254/latest/meta-data/instance-id');
$instance_type = @file_get_contents('http://169.254.169.254/latest/meta-data/instance-type');
$availability_zone = @file_get_contents('http://169.254.169.254/latest/meta-data/placement/availability-zone');

if ($instance_id) {
    echo "<p><strong>Instance ID:</strong> " . $instance_id . "</p>";
    echo "<p><strong>Instance Type:</strong> " . $instance_type . "</p>";
    echo "<p><strong>Availability Zone:</strong> " . $availability_zone . "</p>";
} else {
    echo "<p><strong>Instance Metadata:</strong> Not available (may be running locally)</p>";
}

echo "<hr>";
echo "<p><em>LAMP Stack Application deployed successfully on AWS Elastic Beanstalk! 🎉</em></p>";
echo "<p><a href='health.php'>Check Health Status</a></p>";
?>
