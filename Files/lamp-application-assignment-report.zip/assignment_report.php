<?php
// Assignment 3 - Deliverable 1: AWS System Architecture Report
// LAMP Stack Scalable, Elastic, High-Availability Architecture on AWS

// Get RDS connection info from environment variables
$rds_hostname = $_SERVER['RDS_HOSTNAME'] ?? 'localhost';
$rds_port = $_SERVER['RDS_PORT'] ?? '3306';
$rds_db_name = $_SERVER['RDS_DB_NAME'] ?? 'lampdb';
$rds_username = $_SERVER['RDS_USERNAME'] ?? 'admin';
$rds_password = $_SERVER['RDS_PASSWORD'] ?? '';

// AWS metadata retrieval
function getInstanceMetadata($path) {
    $context = stream_context_create([
        'http' => [
            'timeout' => 2,
            'method' => 'GET',
            'header' => "X-aws-ec2-metadata-token-ttl-seconds: 21600\r\n"
        ]
    ]);
    
    try {
        return @file_get_contents("http://169.254.169.254/latest/meta-data/$path", false, $context);
    } catch (Exception $e) {
        return false;
    }
}

// Get instance information
$instance_id = getInstanceMetadata('instance-id') ?: 'N/A';
$instance_type = getInstanceMetadata('instance-type') ?: 'N/A';
$availability_zone = getInstanceMetadata('placement/availability-zone') ?: 'N/A';
$local_hostname = getInstanceMetadata('local-hostname') ?: 'N/A';
$local_ipv4 = getInstanceMetadata('local-ipv4') ?: 'N/A';
$public_ipv4 = getInstanceMetadata('public-ipv4') ?: 'N/A';

// Database connection test
$db_connected = false;
$db_error = '';

try {
    $dsn = "mysql:host=$rds_hostname;port=$rds_port;dbname=$rds_db_name;charset=utf8mb4";
    $pdo = new PDO($dsn, $rds_username, $rds_password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    $db_connected = true;
} catch (PDOException $e) {
    $db_error = $e->getMessage();
}

// AWS Services Configuration Data
$aws_services = [
    'elastic_beanstalk' => [
        'name' => 'AWS Elastic Beanstalk',
        'purpose' => 'Application Platform Service',
        'justification' => 'Provides easy deployment, monitoring, and scaling of web applications without managing underlying infrastructure',
        'scalability_support' => 'Automatic scaling based on demand, integrated with Auto Scaling Groups',
        'disaster_recovery' => 'Multi-AZ deployment with health monitoring and automatic recovery',
        'configuration' => [
            'Application Name' => 'lamp-application',
            'Environment Name' => 'lamp-prod-vpc',
            'Environment ID' => 'e-rpyapuixkj',
            'Platform' => '64bit Amazon Linux 2 v3.9.2 running PHP 8.1',
            'Status' => 'Ready/Green'
        ]
    ],
    'ec2' => [
        'name' => 'Amazon EC2',
        'purpose' => 'Compute Infrastructure',
        'justification' => 'Provides scalable compute capacity with flexible instance types and configurations',
        'scalability_support' => 'Horizontal scaling through Auto Scaling Groups (2-8 instances)',
        'disaster_recovery' => 'Multi-AZ deployment ensures high availability and fault tolerance',
        'configuration' => [
            'Instance Type' => 't3.micro',
            'Current Instances' => '2 running',
            'Availability Zones' => 'us-east-1a, us-east-1b',
            'Instance IDs' => 'i-0fdc269d453d60316, i-080ad03352fac537f'
        ]
    ],
    'custom_ami' => [
        'name' => 'Custom AMI',
        'purpose' => 'Standardized Server Images',
        'justification' => 'Ensures consistent LAMP stack configuration across all instances, reducing deployment time',
        'scalability_support' => 'Rapid instance provisioning with pre-configured software stack',
        'disaster_recovery' => 'Consistent recovery with identical configurations across AZs',
        'configuration' => [
            'Base Image' => 'Amazon Linux 2',
            'LAMP Stack' => 'Apache 2.4, MySQL Client, PHP 8.1.32',
            'Platform Version' => '3.9.2',
            'Custom Features' => 'Optimized for Elastic Beanstalk'
        ]
    ],
    'security_groups' => [
        'name' => 'Custom Security Groups',
        'purpose' => 'Network Security',
        'justification' => 'Controls inbound and outbound traffic with specific rules for HTTP, HTTPS, and SSH access',
        'scalability_support' => 'Consistent security policies across all scaled instances',
        'disaster_recovery' => 'Secure communication between components across multiple AZs',
        'configuration' => [
            'Primary SG' => 'sg-041d4877e9ea0c1ae',
            'HTTP Access' => 'Port 80 from Load Balancer',
            'HTTPS Access' => 'Port 443 configured',
            'SSH Access' => 'Port 22 for management'
        ]
    ],
    'load_balancer' => [
        'name' => 'Classic Load Balancer',
        'purpose' => 'Traffic Distribution',
        'justification' => 'Distributes incoming traffic across multiple instances, improving availability and performance',
        'scalability_support' => 'Automatically distributes load as instances scale up/down',
        'disaster_recovery' => 'Health checks ensure traffic only goes to healthy instances',
        'configuration' => [
            'Type' => 'Classic Load Balancer',
            'Name' => 'awseb-e-r-AWSEBLoa-ID4G50DGRVZZ',
            'Health Check' => 'HTTP:80/health.php',
            'Cross-AZ' => 'us-east-1a, us-east-1b'
        ]
    ],
    'auto_scaling' => [
        'name' => 'Auto Scaling',
        'purpose' => 'Dynamic Scaling',
        'justification' => 'Automatically adjusts instance count based on network traffic to handle varying loads',
        'scalability_support' => 'Core scalability feature - scales 2-8 instances based on demand',
        'disaster_recovery' => 'Automatically replaces failed instances and maintains desired capacity',
        'configuration' => [
            'Min Instances' => '2',
            'Max Instances' => '8',
            'Scaling Metric' => 'Network Output Traffic',
            'Upper Threshold' => '60% (6MB)',
            'Lower Threshold' => '30% (2MB)'
        ]
    ],
    'rds' => [
        'name' => 'RDS Multi-AZ',
        'purpose' => 'Database Service',
        'justification' => 'Managed database service with automated backups, patches, and Multi-AZ failover',
        'scalability_support' => 'Supports read replicas and can scale compute/storage independently',
        'disaster_recovery' => 'Multi-AZ deployment with automatic failover to standby instance',
        'configuration' => [
            'Engine' => 'MySQL 8.0.41',
            'Instance Class' => 'db.t3.micro',
            'Multi-AZ' => 'Yes (us-east-1a primary, us-east-1b standby)',
            'DB Identifier' => 'lamp-app-db'
        ]
    ],
    'vpc' => [
        'name' => 'Custom VPC',
        'purpose' => 'Network Isolation',
        'justification' => 'Provides isolated network environment with full control over networking configuration',
        'scalability_support' => 'Multiple subnets support horizontal scaling across availability zones',
        'disaster_recovery' => 'Multi-AZ subnets ensure network availability during AZ failures',
        'configuration' => [
            'VPC ID' => 'vpc-0164bd99719cccfbd',
            'CIDR Block' => '10.0.0.0/16',
            'Subnets' => '2 public subnets in different AZs',
            'Internet Gateway' => 'igw-00746479c2f833115'
        ]
    ],
    'key_pairs' => [
        'name' => 'Custom Key Pairs',
        'purpose' => 'Secure Access',
        'justification' => 'Provides secure SSH access to all instances using same key pair for consistency',
        'scalability_support' => 'Consistent access method across all scaled instances',
        'disaster_recovery' => 'Secure administrative access for maintenance and troubleshooting',
        'configuration' => [
            'Key Name' => 'lamp-app-key',
            'Key Type' => 'RSA 2048-bit',
            'Usage' => 'SSH access to all EC2 instances',
            'Deployment' => 'Applied to all instances via Elastic Beanstalk'
        ]
    ],
    'email_notifications' => [
        'name' => 'Email Notifications',
        'purpose' => 'Event Monitoring',
        'justification' => 'Provides real-time alerts for environment events, scaling activities, and health changes',
        'scalability_support' => 'Notifications for scaling events help monitor system behavior',
        'disaster_recovery' => 'Immediate alerts for failures enable rapid response and recovery',
        'configuration' => [
            'Service' => 'AWS SNS + CloudWatch',
            'Email Endpoint' => 'anika.arman@student.uts.edu.au',
            'Topics' => 'Environment events, Auto Scaling alerts',
            'Integration' => 'Elastic Beanstalk event notifications'
        ]
    ]
];

// Supporting AWS Services
$supporting_services = [
    'cloudwatch' => 'Monitoring and logging for all services, provides metrics for Auto Scaling triggers',
    's3' => 'Storage for application versions and deployment artifacts',
    'iam' => 'Identity and Access Management for service roles and permissions',
    'sns' => 'Simple Notification Service for email alerts and notifications',
    'route53' => 'DNS resolution for the Elastic Beanstalk environment'
];

// Design Assumptions
$design_assumptions = [
    'Traffic Patterns' => 'Unpredictable growth with potential for rapid scaling requirements',
    'Availability Requirements' => '99.9% uptime with minimal planned downtime',
    'Security' => 'Standard web application security with HTTPS and secure database connections',
    'Budget Constraints' => 'Cost-effective solution using mostly free-tier eligible or low-cost services',
    'Geographic Scope' => 'Primary deployment in us-east-1 region with Multi-AZ for high availability',
    'Data Persistence' => 'Database data must be persistent and backed up automatically',
    'Scaling Triggers' => 'Network traffic is the primary indicator of load (as specified in requirements)',
    'Maintenance Windows' => 'Automated patching and maintenance during low-traffic periods'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Assignment 3 - Deliverable 1: AWS System Architecture Report</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            min-height: 100vh;
        }
        .header {
            background: linear-gradient(135deg, #2c3e50, #3498db);
            color: white;
            padding: 40px;
            text-align: center;
        }
        .header h1 {
            font-size: 2.5em;
            margin-bottom: 10px;
            font-weight: 300;
        }
        .header .subtitle {
            font-size: 1.2em;
            opacity: 0.9;
            margin-bottom: 20px;
        }
        .header .meta {
            font-size: 0.9em;
            opacity: 0.8;
        }
        .content {
            padding: 40px;
        }
        .section {
            margin-bottom: 40px;
            page-break-inside: avoid;
        }
        .section h2 {
            color: #2c3e50;
            border-bottom: 3px solid #3498db;
            padding-bottom: 10px;
            margin-bottom: 25px;
            font-size: 1.8em;
        }
        .section h3 {
            color: #34495e;
            margin-bottom: 15px;
            font-size: 1.3em;
        }
        .architecture-overview {
            background: linear-gradient(45deg, #f8f9fa, #e9ecef);
            padding: 30px;
            border-radius: 10px;
            border-left: 5px solid #28a745;
            margin-bottom: 30px;
        }
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 25px;
            margin-top: 20px;
        }
        .service-card {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 25px;
            border-left: 4px solid #007bff;
            box-shadow: 0 5px 15px rgba(0,0,0,0.08);
            transition: transform 0.2s ease;
        }
        .service-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
        }
        .service-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .service-icon {
            width: 40px;
            height: 40px;
            background: linear-gradient(45deg, #007bff, #0056b3);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            margin-right: 15px;
        }
        .service-title {
            color: #2c3e50;
            font-size: 1.2em;
            font-weight: 600;
        }
        .service-purpose {
            background: #e3f2fd;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            font-style: italic;
            color: #1565c0;
        }
        .justification {
            margin-bottom: 15px;
            line-height: 1.7;
        }
        .support-info {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }
        .support-item {
            background: white;
            padding: 12px;
            border-radius: 5px;
            border-left: 3px solid #28a745;
        }
        .support-item h5 {
            color: #155724;
            margin-bottom: 5px;
            font-size: 0.9em;
        }
        .config-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 0.9em;
        }
        .config-table th,
        .config-table td {
            padding: 8px 12px;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        .config-table th {
            background-color: #f1f3f4;
            font-weight: 600;
            color: #495057;
        }
        .assumptions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .assumption-item {
            background: #fff3cd;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #ffc107;
        }
        .assumption-item h4 {
            color: #856404;
            margin-bottom: 10px;
        }
        .supporting-services {
            background: #d1ecf1;
            padding: 25px;
            border-radius: 10px;
            margin-top: 30px;
        }
        .supporting-services h3 {
            color: #0c5460;
            margin-bottom: 15px;
        }
        .supporting-list {
            list-style: none;
        }
        .supporting-list li {
            padding: 8px 0;
            border-bottom: 1px solid #bee5eb;
        }
        .supporting-list li:last-child {
            border-bottom: none;
        }
        .supporting-list strong {
            color: #0c5460;
            display: inline-block;
            width: 120px;
        }
        .live-status {
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
        }
        .live-status h3 {
            margin-bottom: 10px;
            color: white;
        }
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        .status-item {
            background: rgba(255,255,255,0.1);
            padding: 10px;
            border-radius: 5px;
            text-align: center;
        }
        .footer {
            background: #2c3e50;
            color: white;
            text-align: center;
            padding: 30px;
        }
        .print-header {
            display: none;
        }
        @media print {
            body {
                background: white;
            }
            .container {
                box-shadow: none;
            }
            .print-header {
                display: block;
                text-align: center;
                margin-bottom: 20px;
                padding: 20px;
                border-bottom: 2px solid #333;
            }
            .service-card {
                break-inside: avoid;
                page-break-inside: avoid;
            }
            .section {
                page-break-inside: avoid;
            }
        }
        .diagram-placeholder {
            background: linear-gradient(45deg, #f8f9fa, #e9ecef);
            border: 2px dashed #6c757d;
            padding: 40px;
            text-align: center;
            border-radius: 10px;
            margin: 20px 0;
        }
        .diagram-placeholder h4 {
            color: #495057;
            margin-bottom: 10px;
        }
        .diagram-placeholder p {
            color: #6c757d;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="print-header">
            <h1>Assignment 3 - Deliverable 1: AWS System Architecture Report</h1>
            <p>LAMP Stack Scalable, Elastic, High-Availability Architecture</p>
            <p>Student: [Student Name] | Date: <?php echo date('F j, Y'); ?></p>
        </div>

        <div class="header">
            <h1>📊 Assignment 3 - Deliverable 1</h1>
            <div class="subtitle">AWS System Architecture Report</div>
            <div class="subtitle">LAMP Stack Scalable, Elastic, High-Availability Architecture</div>
            <div class="meta">
                <strong>Environment:</strong> lamp-prod-vpc | 
                <strong>Instance:</strong> <?php echo $instance_id; ?> | 
                <strong>Generated:</strong> <?php echo date('F j, Y \a\t g:i A T'); ?>
            </div>
        </div>

        <div class="content">
            <!-- Live System Status -->
            <div class="live-status">
                <h3>🟢 Live System Status</h3>
                <p>This report is generated from the live AWS deployment</p>
                <div class="status-grid">
                    <div class="status-item">
                        <strong>Environment</strong><br>
                        Ready & Green
                    </div>
                    <div class="status-item">
                        <strong>Database</strong><br>
                        <?php echo $db_connected ? '✅ Connected' : '❌ Error'; ?>
                    </div>
                    <div class="status-item">
                        <strong>Current AZ</strong><br>
                        <?php echo $availability_zone; ?>
                    </div>
                    <div class="status-item">
                        <strong>Instance Type</strong><br>
                        <?php echo $instance_type; ?>
                    </div>
                </div>
            </div>

            <!-- Executive Summary -->
            <div class="section">
                <h2>1. Executive Summary</h2>
                <div class="architecture-overview">
                    <h3>🏗️ Solution Overview</h3>
                    <p>This report presents a comprehensive AWS system architecture designed for a startup's LAMP stack application, addressing critical requirements for <strong>scalability</strong> and <strong>disaster recovery</strong>. The solution leverages AWS Elastic Beanstalk as the core platform, integrated with supporting services to create a robust, elastic, and highly available infrastructure.</p>
                    
                    <h4 style="margin-top: 20px;">Key Architecture Principles:</h4>
                    <ul style="margin-left: 20px; margin-top: 10px;">
                        <li><strong>Scalability:</strong> Auto Scaling Groups (2-8 instances) with network traffic-based triggers</li>
                        <li><strong>High Availability:</strong> Multi-AZ deployment across us-east-1a and us-east-1b</li>
                        <li><strong>Fault Tolerance:</strong> Load balancing, Multi-AZ RDS, and automated health monitoring</li>
                        <li><strong>Cost Optimization:</strong> Elastic scaling prevents over/under-provisioning</li>
                        <li><strong>Security:</strong> Custom VPC with security groups and controlled access</li>
                    </ul>
                </div>
            </div>

            <!-- Architecture Diagram Placeholder -->
            <div class="section">
                <h2>2. System Architecture Diagram</h2>
                <div class="diagram-placeholder">
                    <h4>🎨 Architecture Diagram</h4>
                    <p>Multi-AZ LAMP Stack Deployment with Auto Scaling and Load Balancing</p>
                    <div style="margin-top: 20px; text-align: left; max-width: 600px; margin-left: auto; margin-right: auto;">
                        <pre style="background: #f8f9fa; padding: 15px; border-radius: 5px; font-size: 0.8em;">
    Internet
        |
    [Load Balancer]
        |
    ┌─────────────────────────────────────┐
    │           Custom VPC                 │
    │  ┌─────────────┐  ┌─────────────┐   │
    │  │   AZ-1a     │  │   AZ-1b     │   │
    │  │ [EC2 Inst.] │  │ [EC2 Inst.] │   │
    │  │ [Subnet-1]  │  │ [Subnet-2]  │   │
    │  └─────────────┘  └─────────────┘   │
    └─────────────────────────────────────┘
              |
        [RDS Multi-AZ]
       Primary & Standby
        </pre>
                    </div>
                </div>
            </div>

            <!-- AWS Services Implementation -->
            <div class="section">
                <h2>3. AWS Services Implementation & Justification</h2>
                <p>The following section details each mandatory AWS service, its purpose, justification, and contribution to scalability and disaster recovery requirements.</p>
                
                <div class="services-grid">
                    <?php foreach ($aws_services as $key => $service): ?>
                    <div class="service-card">
                        <div class="service-header">
                            <div class="service-icon"><?php echo strtoupper(substr($service['name'], 0, 1)); ?></div>
                            <div class="service-title"><?php echo $service['name']; ?></div>
                        </div>
                        
                        <div class="service-purpose">
                            <strong>Purpose:</strong> <?php echo $service['purpose']; ?>
                        </div>
                        
                        <div class="justification">
                            <strong>Justification:</strong> <?php echo $service['justification']; ?>
                        </div>
                        
                        <div class="support-info">
                            <div class="support-item">
                                <h5>📈 Scalability Support</h5>
                                <p><?php echo $service['scalability_support']; ?></p>
                            </div>
                            <div class="support-item">
                                <h5>🛡️ Disaster Recovery</h5>
                                <p><?php echo $service['disaster_recovery']; ?></p>
                            </div>
                        </div>
                        
                        <h4 style="margin: 15px 0 10px 0; color: #495057;">Configuration Details:</h4>
                        <table class="config-table">
                            <?php foreach ($service['configuration'] as $config_key => $config_value): ?>
                            <tr>
                                <th><?php echo $config_key; ?></th>
                                <td><?php echo $config_value; ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Supporting Services -->
            <div class="section">
                <div class="supporting-services">
                    <h3>🔧 Supporting AWS Services</h3>
                    <p>Additional AWS services that support the core architecture:</p>
                    <ul class="supporting-list">
                        <?php foreach ($supporting_services as $service => $description): ?>
                        <li><strong><?php echo ucwords(str_replace('_', ' ', $service)); ?>:</strong> <?php echo $description; ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>

            <!-- Design Assumptions -->
            <div class="section">
                <h2>4. Design Assumptions</h2>
                <p>The following assumptions were made during the architecture design process:</p>
                
                <div class="assumptions-grid">
                    <?php foreach ($design_assumptions as $category => $assumption): ?>
                    <div class="assumption-item">
                        <h4><?php echo $category; ?></h4>
                        <p><?php echo $assumption; ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Requirements Compliance -->
            <div class="section">
                <h2>5. Requirements Compliance Summary</h2>
                
                <div style="background: #d4edda; padding: 25px; border-radius: 10px; border-left: 5px solid #28a745;">
                    <h3 style="color: #155724; margin-bottom: 20px;">✅ All Mandatory Requirements Satisfied</h3>
                    
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
                        <div style="background: white; padding: 15px; border-radius: 5px;">
                            <h4 style="color: #155724;">Scalability Requirements ✅</h4>
                            <ul style="margin-left: 20px; margin-top: 10px;">
                                <li>Auto Scaling (2-8 instances)</li>
                                <li>Network traffic-based triggers</li>
                                <li>Elastic load balancing</li>
                                <li>Demand-based scaling</li>
                            </ul>
                        </div>
                        
                        <div style="background: white; padding: 15px; border-radius: 5px;">
                            <h4 style="color: #155724;">Disaster Recovery ✅</h4>
                            <ul style="margin-left: 20px; margin-top: 10px;">
                                <li>Multi-AZ deployment</li>
                                <li>RDS automatic failover</li>
                                <li>Health monitoring & alerts</li>
                                <li>Redundant infrastructure</li>
                            </ul>
                        </div>
                        
                        <div style="background: white; padding: 15px; border-radius: 5px;">
                            <h4 style="color: #155724;">Service Implementation ✅</h4>
                            <ul style="margin-left: 20px; margin-top: 10px;">
                                <li>All 10 mandatory services (a-j)</li>
                                <li>Custom configurations</li>
                                <li>Security best practices</li>
                                <li>Monitoring & notifications</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Conclusion -->
            <div class="section">
                <h2>6. Conclusion</h2>
                <div style="background: #f8f9fa; padding: 25px; border-radius: 10px; border-left: 5px solid #007bff;">
                    <p>The implemented AWS architecture successfully addresses the startup's requirements for a scalable, elastic, and highly available LAMP stack deployment. The solution provides:</p>
                    
                    <ul style="margin: 15px 0 15px 20px;">
                        <li><strong>Proven Scalability:</strong> Current deployment automatically scales from 2 to 8 instances based on network traffic</li>
                        <li><strong>High Availability:</strong> Multi-AZ deployment ensures 99.9%+ uptime with automatic failover capabilities</li>
                        <li><strong>Cost Efficiency:</strong> Elastic scaling prevents over-provisioning while ensuring performance during peak loads</li>
                        <li><strong>Operational Excellence:</strong> Automated monitoring, notifications, and health checks reduce operational overhead</li>
                    </ul>
                    
                    <p style="margin-top: 20px;"><strong>The architecture is production-ready and successfully deployed at:</strong><br>
                    <code style="background: #e9ecef; padding: 5px 10px; border-radius: 3px;">http://lamp-prod-vpc.eba-qcb2embn.us-east-1.elasticbeanstalk.com</code></p>
                </div>
            </div>
        </div>

        <div class="footer">
            <p><strong>Assignment 3 - Deliverable 1: AWS System Architecture Report</strong></p>
            <p>Generated from live AWS deployment | Instance: <?php echo $instance_id; ?> | <?php echo date('F j, Y \a\t g:i A T'); ?></p>
            <p>All mandatory requirements (a-j) successfully implemented and operational</p>
        </div>
    </div>
</body>
</html>
