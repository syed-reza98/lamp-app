<?php
echo "Hello LAMP Stack!";
echo "<br>PHP Version: " . phpinfo(INFO_GENERAL);
