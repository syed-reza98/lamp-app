<?php
$_GET['detail'] = 'enhanced';
include 'health_unified.php';
